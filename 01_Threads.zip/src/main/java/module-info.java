module threads {
    opens as;

    requires java.desktop;
    requires java.management;
    requires javafx.base;
    requires javafx.controls;
    requires javafx.graphics;
}