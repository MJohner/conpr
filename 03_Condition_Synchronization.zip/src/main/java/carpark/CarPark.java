package carpark;

public interface CarPark {
    void enter();
    void exit();
}
