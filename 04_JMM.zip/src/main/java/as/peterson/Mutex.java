package as.peterson;

public interface Mutex {
    void lock();
    void unlock();
}
