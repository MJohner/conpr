package bank.local;

import bank.gui.ClientFX;

/**
 * Launcher for the ConprBank.
 */
public class ConprBankLauncher {
	public static void main(String[] args) {
		ClientFX.main(new String[] { ConprBankDriver.class.getName() });
	}
}
  