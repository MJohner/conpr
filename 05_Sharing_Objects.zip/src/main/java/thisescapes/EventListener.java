package thisescapes;

interface EventListener {
    void objectChanged();
}